# ethtrader.org

A deploy-ready static website package for GitHub + Vercel.

## Included

- `index.html` — main site file
- `assets/` — folders for images, icons, and logos
- `vercel.json` — optional Vercel config for clean URLs
- `.gitignore` — basic ignore file

## Exact folder structure

```bash
ethtrader-full/
├── index.html
├── README.md
├── vercel.json
├── .gitignore
└── assets/
    ├── images/
    ├── icons/
    └── logos/
```

## Upload to GitHub

### Browser method
1. Create a new repository on GitHub.
2. Open the repository.
3. Click **Add file** → **Upload files**.
4. Upload all files and folders from this package.
5. Commit directly to the `main` branch.

### Git command line method
```bash
cd ethtrader-full
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```

## Deploy to Vercel

1. Sign in to Vercel.
2. Click **Add New** → **Project**.
3. Import your GitHub repository.
4. Keep the project root as default.
5. For a static site, leave build settings blank.
6. Click **Deploy**.

## Connect custom domain

1. In Vercel, open your project.
2. Go to **Settings** → **Domains**.
3. Add `ethtrader.org`.
4. Add `www.ethtrader.org` too if you want both versions.
5. Copy the DNS records Vercel gives you.
6. Add those DNS records where your domain is registered.
7. Wait for verification.

## Typical DNS pattern

Use the exact values Vercel shows in your dashboard.
Common setup:

- Apex/root domain:
  - Type: `A`
  - Host: `@`
  - Value: `76.76.21.21`
- WWW:
  - Type: `CNAME`
  - Host: `www`
  - Value: `cname.vercel-dns.com`

## Important notes

- Keep `index.html` in the root.
- Put future images inside `assets/images/`.
- Reference assets with relative paths like `./assets/images/example.png`.
- Every push to GitHub can trigger a new Vercel deployment.
